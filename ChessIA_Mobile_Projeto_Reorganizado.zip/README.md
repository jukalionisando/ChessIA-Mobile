# ChessIA Mobile Advanced 2.0

Projeto Android inicial para tabuleiro e análise ChessIA.

## Build APK
O workflow GitHub Actions está em `.github/workflows/build-apk.yml`.
Abra Actions e execute `Build ChessIA APK` usando `Run workflow`.
O APK debug é publicado como Artifact.

## Nota
Esta é uma versão de protótipo. O overlay é um atalho flutuante que abre o app; não lê automaticamente tabuleiros de Chess.com/Lichess. A análise depende dos recursos implementados no `index.html` e da conectividade externa.
